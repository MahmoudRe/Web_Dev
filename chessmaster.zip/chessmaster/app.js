var express = require("express");
var http = require("http");
var websocket = require("ws");

var indexRouter = require("./routes/index");

var port = process.argv[2];
var app = express();

app.use(express.static(__dirname + "/public"));

app.get("/", indexRouter);
app.get("/game", indexRouter);

var server = http.createServer(app);
const wss = new websocket.Server({server});

// wss.on("connection", function(ws) {

//   ws.onmessage = (msg) => {
//     console.log(msg);
//     const board_arr2 = JSON.parse(msg)[0];
//     ws.send("server massege");
  
//     const board_div =  JSON.parse(msg)[1];
//     document.getElementById("board").innerHTML = board_div;
//   };

//   setTimeout(function() {
//     ws.send("server massege");
//   }, 3000);

//   // ws.on("message", function incoming(message) {
//   //   console.log("[LOG]" + message);
//   // });
// });

server.listen(port);

